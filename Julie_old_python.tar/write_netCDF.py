#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov  9 13:42:20 2018

@author: jlundqui
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math
from matplotlib.ticker import FormatStrFormatter
import glob
import os
import ftplib
import netCDF4


##-------------------HELPER FUNCTIONS------------------
##-----------------------------------------------------
def timeStrToFloat (x):	
	time = x.split(':')			
	time = [float(x) for x in time]        
	float_time_hr = time[0] + time[1]/60 + time[2]/3600			
	return float_time_hr        


##---------------** END **-----------------------------
##-----------------------------------------------------

##-----------------------------------------------------
##              MAIN PROGRAM 
##-----------------------------------------------------

# read in the file

path_in = '/Users/jlundqui/Documents/lidar/ISARRA_2018/'
path_out = path_in

file_count = 2
#sorted_files = sorted(glob.iglob(path_in + 'Converted_WLS7-00*_2018_07_14__00_00_00.rtd'), reverse=True) #key=os.path.getctime,  
sorted_files = sorted(glob.iglob(path_in + 'Converted_WLS7-00*.rtd'), reverse=True) #key=os.path.getctime,  
last_files = [sorted_files[i] for i in np.arange(file_count)]

# read file, plot winds from both lidars for the 14th

nfile = np.arange(file_count)

for nfile in nfile:
    fname = last_files[nfile].split('/')[-1]

    f = open(path_in + fname, encoding='iso-8859-1')  # thanks Leosphere  
    lines=[]
    # Read from File # This line causes problems although can read in data OK otherwise.
    for line in f: 
        lines.append(line.split())

#    3 ID System=WLS7-0068
    IDSystem_line = lines[2]
    test = (IDSystem_line[1]) #this is still a string
    IDSystem = test.split('=')[1]
    lidar=IDSystem

#    6 GPS Localisation=38°05'55.57"N 106°10'13.15"W 2387.2m    
    latlong_line = lines[5]
    latitude = (latlong_line[1].split('='))[1]
    longitude = latlong_line[2]
    elevation = latlong_line[3]
    latlong = latitude+' , '+longitude
    
#   10 ScanAngle(°)=27.86
    scan_angle_line = lines[9]
    scan_angle = (scan_angle_line[0].split('='))[1] #this is still a string
    
#   11 NumberOfAveragedShots=10000
    NumberOfAveragedShots_line = lines[10]
    NumberOfAveragedShots = (NumberOfAveragedShots_line[0].split('='))[1] #this is still a string
    
#   12 RollAngle(°)=0.40
    RollAngle_line = lines[11]
    RollAngle = (RollAngle_line[0].split('='))[1]
#   13 HeadingAngle(°)=-17.80
    HeadingAngle_line = lines[12]
    HeadingAngle = (HeadingAngle_line[0].split('='))[1]
#   15 PitchAngle(°)=-0.20
    PitchAngle_line = lines[14]
    PitchAngle = (PitchAngle_line[0].split('='))[1]
    
#   14 Altitudes(m)=   40      60      80      100     120     140     160     180     200     220
    Altitudes_line = lines[13]
    Altitudes_strlist = Altitudes_line[1:]
    Altitudes_strlist = Altitudes_strlist[1:]
    Altitudes = [float(item) for item in Altitudes_strlist]

#   16 CNRThreshold=-22
    CNRThreshold_line = lines[15]
    CNRThreshold = (CNRThreshold_line[0].split('='))[1]

#   20 Wavelength(nm)=1543.00    
    wavelength_nm_line = lines[19]
    wavelength_nm = (wavelength_nm_line[0].split('='))[1] #this is still a string

#   22 DirectionOffset(°)=0.000
    DirectionOffset_line = lines[21]
    DirectionOffset = (DirectionOffset_line[0].split('='))[1]

#   31 NumberOfSamples_LaserPulse=74
    NumberOfSamples_LaserPulse_line = lines[30]
    NumberOfSamples_LaserPulse = (NumberOfSamples_LaserPulse_line[0].split('='))[1]
       
    lines = lines[57:]

    if fname[10:14] == 'WLS7':
        print(fname)

        # Convert to numpy format array
        data = np.array(lines)

        if fname[25:27] == '01':
            month = 'Jan'
        elif fname[25:27] == '02':
            month = 'Feb'
        elif fname[25:27] == '03':
            month = 'Mar'
        elif fname[25:27] == '04':
            month = 'Apr'
        elif fname[25:27] == '05':
            month = 'May'
        elif fname[25:27] == '06':
            month = 'Jun'
        elif fname[25:27] == '07':
            month = 'Jul'
        elif fname[25:27] == '08':
            month = 'Aug'
        elif fname[25:27] == '09':
            month = 'Sep'
        elif fname[25:27] == '10':
            month = 'Oct'
        elif fname[25:27] == '11':
            month = 'Nov'
        elif fname[25:27] == '12':
            month = 'Dec'
        else:
            raise TypeError('That month (' + fname[25:27]  +  ') is not within the calendar year!')

        year = fname[20:24]
        day = fname[28:30]
        mon = fname[25:27]
        hour = fname[32:34]
        min = fname[35:37]

        time_str = data[:,1]
        time_array = np.array([timeStrToFloat(x) for x in time_str.tolist()])
        
        beam_str = data[:,2]
        justdata = data[:,5:]

        n_lines = np.shape(justdata)[0]
        n_heights = np.shape(justdata)[1]/8

        justdata_shaped = np.reshape(justdata,(int(n_lines),int(n_heights),8))
        CNR = justdata_shaped[:,:,0].astype(np.float) #hard to evaluate
        RWS = justdata_shaped[:,:,1].astype(np.float)
        RWSD = justdata_shaped[:,:,2].astype(np.float)
        V_h = justdata_shaped[:,:,3].astype(np.float)
        Azi = justdata_shaped[:,:,4].astype(np.float)
        u = justdata_shaped[:,:,5].astype(np.float)
        v = justdata_shaped[:,:,6].astype(np.float)
        w = justdata_shaped[:,:,7].astype(np.float)
        
        # Correct orientation NOW
        u = -v
        v = -u
        w = -w 


# Need to apply an offset of 1220.4 seconds or 20.34 minutes or 0.339 hours. 
# Which system was correct? Rereading of PAtrick's notes at
# https://docs.google.com/document/d/1RAjP7nu-WAbf0bjvjB0V8_0tMQsguLRH84T8hI4Fp2s/edit
# indicate that WC49 is the fast one. This is the second one stored in the array somehow

# Should write out the entire contents of the rtd files just with offset in time. 

#xxx.ppppp.lv.yyyymmdd.hhmmss.cdf
#
#xxx 		- Institute (see appendix 1)
#ppppp		- 5-letter platform identifier (see appendix 2)
#lv		- Data file processing level (see section 4)
#hhmmss	- File start time (UTC) in hours, minutes, seconds
#yyyymmdd	- File date (UTC) in year, month, day, month
#cdf		- NetCDF file extension
#
#As an example, a CU DataHawk NetCDF file collected starting at 11:30:54 UTC on 17 July, 2018 containing non-QC’d physical units would be named: 
#
#UCB.DATHK.a1.20180717.113054.cdf
#UCB:	University of Colorado Boulder
#DPLR1:	CU Doppler Lidar 1  WLS7-0049
#DPLR2:	CU Doppler Lidar 2  WLS7-0068
        if lidar == 'WLS7-0068':
            lidartag == 'DPLR2'
        elif lidar == 'WLS7-0049':
            lidartag == 'DPLR1'
        else:
              raise TypeError('That lidar (' + lidar  +  ') is not identified with an ISARRA tag!')
          
        
        from netCDF4 import Dataset
        dataset = Dataset('UCB.'+lidar+'.a1.'+year+mon+day+'.'+hour+min+sec+'.cdf','w',format='NETCDF4_CLASSIC')

        level = dataset.createDimension('level', n_heights)
#lat = dataset.createDimension('lat', 73)
#lon = dataset.createDimension('lon', 144)
        time = dataset.createDimension('time', None)
#All of the Dimension instances are stored in a python
#dictionary. This allows you to access each dimension by
#its name using dictionary key access:
#print 'Lon dimension:'
#, dataset.dimensions['lon']
#for dimname in dataset.dimensions.keys():
# dim = dataset.dimensions[dimname]
# print dimname, len(dim), dim.isunlimited()
#Lon dimension: <type 'netCDF4.Dimension'>: name = 'lon', size = 144
#level 10 False
#time 0 True
#lat 73 False
#lon 144 False
 
#import time
## Global Attributes
#dataset.description = 'bogus example script'
#dataset.history = 'Created ' + time.ctime(time.time())
#dataset.source = 'netCDF4 python module tutorial'

## Global Attributes
        dataset.ID_system = 'WLS7-0068'
        dataset.history = 'Created ' + time.ctime(time.time())
        dataset.source = 'Julie.Lundquist@colorado.edu'
        dataset.ScanAngle = scan_angle #from file
        dataset.latitude = latitude   #### rewrite this string as float
        dataset.longituge = longitude  #### rewrite this string as float
        dataset.altitude = elevation #### rewrite this string as float
        dataset.laser_wavelength = wavelength_nm
        dataset.roll_angle = RollAngle
        dataset.heading_angle = HeadingAngle
        dataset.pitch_angle = PitchAngle
        dataset.CNR_threshold = CNRThreshold
        dataset.direction_offset = DirectionOffset
        dataset.NumberOfAveragedShots = NumberOfAveragedShots
        dataset.NumberOfSamples_LaserPulse = NumberOfSamples_LaserPulse
        dataset.ReceiverBandwidth = '+- 55 MHz for v1'
        dataset.NyquistVelocity_mps = '+- 42.3 m s-1'
        dataset.SignalSpectralWidth = '3.39 m s-1'

## Create coordinate variables for 4-dimensions
#times = dataset.createVariable('time', np.float64, ('time',))
#levels = dataset.createVariable('level', np.int32, ('level',))
        UTC_Time = dataset.createVariable('UTC_Time', None)
        UTC_Time.units = 's'
        UTC_Time.description = 'UTC Time (Seconds since 00:00:00, 1 January 1970)'
        UTC_Time._FillValue = -9999.9
        
        Height = dataset.createVariable('Height', np.int32, ('level',))
        Height.units = 'm'
        Height.description = 'meters above the surface'
        Height._FillValue = -9999.9
#latitudes = dataset.createVariable('latitude', np.float32,
#('lat',))
#longitudes = dataset.createVariable('longitude', np.float32,
#('lon',))
## Create the actual 4-d variable
#temp = dataset.createVariable('temp', np.float32,
#('time','level','lat','lon'))

        U = dataset.createVariable('U', np.float32, ('time','level'))
## Variable Attributes
        U.units = 'm/s'
        U.description = 'Derived wind vector projection along x-axis (west -> east)'
        U._FillValue = -9999.9
#longitudes.units = 'degree_east'
#levels.units = 'hPa'
#temp.units = 'K'
#times.units = 'hours since 0001-01-01 00:00:00'
#times.calendar = 'gregorian'

        V = dataset.createVariable('V', np.float32, ('time','level'))
        V.units = 'm/s'
        V.description = 'Derived wind vector projection along y-axis (south -> north)'
        V._FillValue = -9999.9

        W = dataset.createVariable('W', np.float32, ('time','level'))
        ## Variable Attributes
        W.units = 'm/s'
        W.description = 'Derived wind vector projection along z-axis (down -> up)'
        W._FillValue = -9999.9

        WS = dataset.createVariable('WS', np.float32, ('time','level'))
        ## Variable Attributes
        WS.units = 'm/s'
        WS.description = 'Derived horizontal wind speed'
        WS._FillValue = -9999.9

        WD = dataset.createVariable('WD', np.float32, ('time','level'))
        ## Variable Attributes
        WD.units = 'm/s'
        WD.description = 'Derived horizontal wind direction, 0=North, 90=East'
        WD._FillValue = -9999.9

        Beam = dataset.createVariable('Beam', np.int32, ('time'))
        ## Variable Attributes
        Beam.units = 'deg'
        Beam.description = 'Azimuth angle of beam'
        Beam._FillValue = -9999.9

        InternalTemp = dataset.createVariable('InternalTemp', np.int32, ('time'))
        ## Variable Attributes
        Beam.units = 'deg C'
        Beam.description = 'Internal temperature of lidar (overheating flag)'
        Beam._FillValue = -9999.9

        CNR = dataset.createVariable('CNR', np.float32, ('time','level'))
        ## Variable Attributes
        CNR.units = 'dB'
        CNR.description = 'Carrier to Noise Ratio'
        CNR._FillValue = -9999.9

        RWS = dataset.createVariable('RWS', np.float32, ('time','level'))
        ## Variable Attributes
        RWS.units = 'm/s'
        RWS.description = 'Radial wind speed along the beam'
        RWS._FillValue = -9999.9

        RWSD = dataset.createVariable('RWSD', np.float32, ('time','level'))
        ## Variable Attributes
        RWSD.units = 'm/s'
        RWSD.description = 'Standard deviation of radial wind speed along the beam'
        RWSD._FillValue = -9999.9

#import time
## Global Attributes
#dataset.description = 'bogus example script'
#dataset.history = 'Created ' + time.ctime(time.time())
#dataset.source = 'netCDF4 python module tutorial'

## Variable Attributes
#latitudes.units = 'degree_north'
#longitudes.units = 'degree_east'
#levels.units = 'hPa'
#temp.units = 'K'
#times.units = 'hours since 0001-01-01 00:00:00'
#times.calendar = 'gregorian'

#a0: 	Raw data converted to netCDF
#a1: 	Calibration factors applied and converted to geophysical units
#b1: 	QC checks applied to measurements to ensure that they are “in bounds”.  Missing data points or those with bad values should be set to -9999.9
#c1:	Derived or calculated value-added data product (VAP) using one or more measured or modeled data (a0 to c1) as input
#Note: It is NOT required (or expected) to submit all data levels.  Specifically, a0 data may not be useful to many interested users and may not be made available by many groups.  The most useful data levels for most users will likely be a1 and b1, and this is the data level that is most desired from all groups.

#For stationary platforms (e.g. CLAMPS sensors, Doppler Lidars, MURC, stationary towers), these include:
#Index Units:
#UTC Time (Seconds since 00:00:00, 1 January 1970)

#Now need to fill in the values, being sure to convert from Leosphere units to meteorological units.


