#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tues Nov 6 2018 

@author: jlundqui modifying jeto code
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math
from matplotlib.ticker import FormatStrFormatter
import glob
import os
import ftplib


##-------------------HELPER FUNCTIONS------------------
##-----------------------------------------------------
def timeStrToMin(x):
	time = x.split(':')
	time = [float(x) for x in time]
	tMins = time[0]*60 + time[1]
	return tMins

#def timeMinToStr(x):
#	hrs = x /60
#	mins= x % 60
#	h_s = str(hrs)
#	m_s = str(mins)
#	if(len(h_s) < 2):
#		h_s = '0'+h_s
#	if(len(m_s) < 2):
#		m_s = '0'+m_s
#	return h_s+':'+m_s+':'+'00'

def timeStrToFloat (x):	
	time = x.split(':')			
	time = [float(x) for x in time]        
	float_time_hr = time[0] + time[1]/60 + time[2]/3600			
	return float_time_hr        


#def fixMissingTime(matrix,time_array_str):
#	# We know that there has to be 720 columns	
#	n_times = time_array_str.shape
#	if n_times[0] == 720:
#		#print("Already has complete data !! Exiting ")
#		return matrix				
#	# n_rows,n_cols = matrix.shape	
#	st_time = 2
#	index = 0
#	hit_count = 0
#	final_matrix = np.empty((10,721-n_times[0]))
#	final_matrix[:] = np.NAN
#	while st_time < 1441:				
#		st_time_str = timeMinToStr(st_time)
#		if st_time_str in time_array_str:
#			hit_count = hit_count+1			
#			src_index = np.where(time_array_str==st_time_str)[0][0]
#			# print(st_time_str,src_index,index)
#			# print(matrix[:,src_index])
#			final_matrix = np.insert(final_matrix,index, matrix[:,src_index],axis=1)			
#		st_time = st_time + 2
#		index = index + 1
#	return final_matrix[:,0:720]

def fixWDwrtWS(WD_matrix, WS_matrix):
	newWD_matrix = WD_matrix
	for r in range(0,10):
		for c in range(0,720):
			if math.isnan(WS_matrix[r,c]) and (WD_matrix[r,c] >= 0.0):
				newWD_matrix[r,c] = np.NAN
	return newWD_matrix

##---------------** END **-----------------------------
##-----------------------------------------------------

##-----------------------------------------------------
##              MAIN PROGRAM 
##-----------------------------------------------------


path_in = '/Users/jlundqui/Documents/lidar/ISARRA_2018/'
path_out = path_in

file_count = 2
sorted_files = sorted(glob.iglob(path_in + 'Converted_WLS7-00*_2018_07_14__00_00_00.rtd'), reverse=True) #key=os.path.getctime,  
last_files = [sorted_files[i] for i in np.arange(file_count)]

# read file, plot winds from both lidars for the 14th

nfile = np.arange(file_count)

for nfile in nfile:
    fname = last_files[nfile].split('/')[-1]

    f = open(path_in + fname, encoding='iso-8859-1')  # thanks Leosphere  
    lines=[]
    # Read from File # This line causes problems although can read in data OK otherwise.
    for line in f: 
        lines.append(line.split())
        print('near lines.append')
        print(lines)
        print(np.shape(lines))

#    1 HeaderLength=55
#    2 Version=3.1.66
#    3 ID System=WLS7-0068
#    4 ID Client=University of Colorado
#    5 Localisation=RNRG courtyard
#    6 GPS Localisation=38°05'55.57"N 106°10'13.15"W 2387.2m
#    7 Comments=v1+ update test
#    8 Measurements informations :
#    9 ********************
#   10 ScanAngle(°)=27.86
#   11 NumberOfAveragedShots=10000
#   12 RollAngle(°)=0.40
#   13 HeadingAngle(°)=-17.80
#   14 Altitudes(m)=   40      60      80      100     120     140     160     180     200     220
#   15 PitchAngle(°)=-0.20
#   16 CNRThreshold=-22
#   17 WiperCNRThreshold=-19.0
#   18 WiperAltitude(m)=100.0
#   19 WiperDuration(ms)=1000.0
#   20 Wavelength(nm)=1543.00
#   21 Angle BetweenTwoPositions(°)=90
#   22 DirectionOffset(°)=0.000
#   23 Algorithm Parameters :
#   24 ********************
#   25 Algorithm=MLE
#   26 MAOFrequency(Hz)=68000000.000
#   27 CutOffFrequency(Hz)=90000000.000
#   28 WindowLength(s)=0.000000E+0
#   29 IndexRange0=70
#   30 PathLaserPulse=C:\Program Files\Leosphere\windsoft\pulse_laser.sig
#   31 NumberOfSamples_LaserPulse=74
#   32 BeginIndex_LaserPulse=0
#   33 BeginIndex_NoiseReference=0
#   34 NumberOfNoiseWindowsByProfile=1
#   35 VrThreshold (m/s)=)1.700
#   36 SigmaFreqThreshold (m/s)=)0.750
#   37 Acquisition Parameters :
#   38 ********************
#   39 SamplingInterval=4.000000E-9
#   40 NumberOfSamples=1024
#   41 VerticalCoupling=AC, 50 Ohm
#   42 Offset=0.000
#   43 FullScale=0.200
#   44 NumberOfSegments=100
#   45 TriggerSource=External
#   46 TriggerCoupling=DC, 50 Ohm (Ext. trig. only)
#   47 TriggerSlope=Positive
#   48 TriggerLevel1=3000
#   49 TriggerLevel2=0
#   50 DelayLine=4.000000E-7
#   51 AbsoluteInitialPosition(°)=122040
#   52 RelativeInitialPosition(°)=0
#   53 InitialDate/Time=14/07/2018 00:00:00.68
#   54 Gain=32.797000
#   55 InitialLD1(mA)=IC1=320
#   56 InitialLD2(mA)=IC2=1650
#   57 Date    Position        Temperature (°C)        Wiper   CNR-1   RWS-1   RWSD-1  Vh-1    Azi (°)-1             u-1     v-1     w-1     CNR-2   RWS-2   RWSD-2  Vh-2    Azi (°)-2       u-2     v-2     w-2     CNR-3         RWS-3   RWSD-3  Vh-3    Azi (°)-3       u-3     v-3     w-3     CNR-4   RWS-4   RWSD-4  Vh-4    Azi (°)-      4       u-4     v-4     w-4     CNR-5   RWS-5   RWSD-5  Vh-5    Azi (°)-5       u-5     v-5     w-5           CNR-6   RWS-6   RWSD-6  Vh-6    Azi (°)-6       u-6     v-6     w-6     CNR-7   RWS-7   RWSD-7  Vh-7          Azi (°)-7       u-7     v-7     w-7     CNR-8   RWS-8   RWSD-8  Vh-8    Azi (°)-8       u-8     v-8           w-8     CNR-9   RWS-9   RWSD-9  Vh-9    Azi (°)-9       u-9     v-9     w-9     CNR-10  RWS-10  RWSD-10       Vh-10   Azi (°)-10      u-10    v-10    w-10

#    3 ID System=WLS7-0068
    IDSystem_line = lines[2]
    test = (IDSystem_line[1]) #this is still a string
    IDSystem = test.split('=')[1]
    lidar=IDSystem

#    6 GPS Localisation=38°05'55.57"N 106°10'13.15"W 2387.2m    
    latlong_line = lines[5]
    latitude_str = (latlong_line[1].split('='))[1]
    latitude_deg_str = (latitude_str.split("°"))[0]
    latitude_deg = np.float(latitude_deg_str)
    latitude_min_str = (latitude_str.split("°"))[1]
    longitude_str = latlong_line[2]

    elevation_str = latlong_line[3]
    elevation = np.float(elevation_str[0:6])

    latlong = latitude_str+' , '+longitude_str
    
#   10 ScanAngle(°)=27.86
    scan_angle_line = lines[9]
    scan_angle = (scan_angle_line[0].split('='))[1] #this is still a string
    
#   11 NumberOfAveragedShots=10000
    NumberOfAveragedShots_line = lines[10]
    NumberOfAveragedShots = (NumberOfAveragedShots_line[0].split('='))[1] #this is still a string
    
#   12 RollAngle(°)=0.40
    RollAngle_line = lines[11]
    RollAngle = (RollAngle_line[0].split('='))[1]
#   13 HeadingAngle(°)=-17.80
    HeadingAngle_line = lines[12]
    HeadingAngle = (HeadingAngle_line[0].split('='))[1]
#   15 PitchAngle(°)=-0.20
    PitchAngle_line = lines[14]
    PitchAngle = (PitchAngle_line[0].split('='))[1]
    
#   14 Altitudes(m)=   40      60      80      100     120     140     160     180     200     220
    Altitudes_line = lines[13]
    Altitudes_strlist = Altitudes_line[1:]
    Altitudes_strlist = Altitudes_strlist[1:]
    Altitudes = [float(item) for item in Altitudes_strlist]

#   16 CNRThreshold=-22
    CNRThreshold_line = lines[15]
    CNRThreshold = (CNRThreshold_line[0].split('='))[1]

#   20 Wavelength(nm)=1543.00    
    wavelength_nm_line = lines[19]
    wavelength_nm = (wavelength_nm_line[0].split('='))[1] #this is still a string

#   22 DirectionOffset(°)=0.000
    DirectionOffset_line = lines[21]
    DirectionOffset = (DirectionOffset_line[0].split('='))[1]

#   31 NumberOfSamples_LaserPulse=74
    NumberOfSamples_LaserPulse_line = lines[30]
    NumberOfSamples_LaserPulse = (NumberOfSamples_LaserPulse_line[0].split('='))[1]
       
    
    lines = lines[57:]
    print('looking at the shape of lines near line 226')
    print(np.shape(lines))
    # JKL: write a clause here to give lat/long for the right windcube
    #latlon = r"45.5899$^{\circ}$N, -120.672044$^{\circ}$W"
    #elev = '455 m'
    #site = 'Wasco'
    
    
#    #check which site
#    if fname[15:19] == '0068':
#        lidar = 'WC68'
#        latlon = r"38.09877$^{\circ}$N, -106.17028$^{\circ}$W"
#        elev = '2388 m'
#        site = 'Saguache'
#    elif fname[15:19] == '0049':
#        lidar = 'WC49'
#        latlon = r"8.09877$^{\circ}$N, -106.17028$^{\circ}$W"
#        elev = '2388 m'
#        site = 'Saguache'

          
    # check we have a normal full day file
    
    #if fname[-6:-4] == '00':
    if fname[10:14] == 'WLS7':
        print(fname)

        # Convert to numpy format array
        print('looking at the shape of lines')
        print(np.shape(lines))
        data = np.array(lines)
        print('looking at the shape of data')
        print(np.shape(data))
        

        if fname[25:27] == '01':
            month = 'Jan'
        elif fname[25:27] == '02':
            month = 'Feb'
        elif fname[25:27] == '03':
            month = 'Mar'
        elif fname[25:27] == '04':
            month = 'Apr'
        elif fname[25:27] == '05':
            month = 'May'
        elif fname[25:27] == '06':
            month = 'Jun'
        elif fname[25:27] == '07':
            month = 'Jul'
        elif fname[25:27] == '08':
            month = 'Aug'
        elif fname[25:27] == '09':
            month = 'Sep'
        elif fname[25:27] == '10':
            month = 'Oct'
        elif fname[25:27] == '11':
            month = 'Nov'
        elif fname[25:27] == '12':
            month = 'Dec'
        else:
            raise TypeError('That month (' + fname[25:27]  +  ') is not within the calendar year!')

        year = fname[20:24]
        day = fname[28:30]
        mon = fname[25:27]
        hour = fname[32:34]
        min = fname[35:37]

        time_str = data[:,1]
        time_array = np.array([timeStrToFloat(x) for x in time_str.tolist()])

        print(time_array)
        
        
        #stop thinking about any data past 2000 UTC when the lidars were moved
        end_time = 20
        last_time_index = np.min(np.where(time_array > 20)) - 1
        
        print(np.shape(data))
        
        data = data[0:last_time_index,:]
        
        beam_str = data[:,2]
        justdata = data[:,5:]

        n_lines = np.shape(justdata)[0]
        n_heights = np.shape(justdata)[1]/8

        justdata_shaped = np.reshape(justdata,(int(n_lines),int(n_heights),8))
        CNR = justdata_shaped[:,:,0].astype(np.float) #hard to evaluate
        RWS = justdata_shaped[:,:,1].astype(np.float)
        RWSD = justdata_shaped[:,:,2].astype(np.float)
        V_h = justdata_shaped[:,:,3].astype(np.float)
        Azi = justdata_shaped[:,:,4].astype(np.float)
        u = justdata_shaped[:,:,5].astype(np.float)
        v = justdata_shaped[:,:,6].astype(np.float)
        w = justdata_shaped[:,:,7].astype(np.float)
                
        #replace -999 values with NaN
        #Altitudes = [float(item) for item in Altitudes_strlist]
#import numpy as N
#a = N.arange(8)
#condition = N.logical_and(a>3, a<6)
#answer_indices = N.where(condition)
##answer = (a*2)[answer_indices]
#answer = N.where(condition, a*2, 0)
#import numpy as N
#a = N.arange(8)
#condition = N.logical_and(a>3, a<6)
#answer = ((a*2)*condition) + \
#(0*N.logical_not(condition))
    
#        condition = np.logical_or(CNR<-22,V_h<-30)
        
#        baddata = np.where(condition,np.isnan,)
               
        print("In filename" + fname + " we have "+ str(n_lines) + " lines and " + str(n_heights) + " heights")
    
        ws = np.sqrt(u**2 + v**2)


        # PLOTTING
    
        z = np.array([40,60,80,100,120,140,160,180,200,220])
        #timeUTC = np.linspace(0,2401,720)
        timeUTC = np.linspace(0,end_time,n_lines)

        transpose_V_h = np.transpose(V_h)


        fig = plt.figure(figsize=[14,7])
        ax = plt.subplot(111)

        # fontsizes:
        colorbar_fs = 16
        label_fs = 24
        tick_fs = 16
        key_fs = 14

# Now plot a time series at one specific height
        desired_height = 80.
        this_height_index = (np.where(z > desired_height))[0] -1 
        this_height_index = this_height_index[0]
        print(z[this_height_index])
        plt.plot(timeUTC,Azi[:,this_height_index])
        plt.xlabel('Time (UTC)', fontsize=label_fs)
#        plt.ylabel(r'Vhm (m s$^{-1}$)', fontsize=label_fs)
        plt.ylabel(r'Azi (deg)', fontsize=label_fs)
        plt.tick_params(axis='both', which='major', labelsize=tick_fs)
        ax.xaxis.set_major_formatter(FormatStrFormatter('%02d'))
#        plt.suptitle(str(z[this_height_index]) + ' m winds on ' + day + ' '  +  month + ' ' + year + ' '+ site + ' ' + lidar, fontsize=label_fs, x=0.45, y=1)
        plt.suptitle(str(z[this_height_index]) + ' m winds on ' + day + ' '  +  month + ' ' + year + ' ' + ' ' + lidar, fontsize=label_fs, x=0.45, y=1)
        plt.title(latlon + ' at ' + elev, fontsize=colorbar_fs, ha='center')
        plt.grid()
#        plt.xlim(0,end_time)
        plt.xlim(8,11)
#        plt.ylim(0,15)
        plt.ylim(0,360)
        plt.show
        plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.WindDirTimeSeries' + str(z[this_height_index]) + 'm.png', 
            dpi=300)
#        savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.WindsTimeSeries'+str(z[this_height_index])+'m.png', bbox_inches='tight')


# the time series from WC 49 is much noisier than that from WC68

# now need to have both of them on the same axis so that we can calculate an autocorrelation.
        
        

#        #horizontal
#        contour_levels = np.arange(0, np.nanmax(V_h)-1, 0.5) #16?
#        #contour_levels = np.arange(np.floor(np.nanmin(fixed_w)), np.ceil(np.nanmax(fixed_w)), 0.25)
#
#        barb_stagger = 20
#
#        transpose_V_h = np.transpose(V_h)
#        CS = plt.contourf(timeUTC, z, transpose_V_h, contour_levels, extend='max', cmap='viridis')
##        B = plt.barbs(timeUTC[::barb_stagger], z, -v[:,::barb_stagger]*1.94, -u[:,::barb_stagger]*1.94,
##            barbcolor='black', flagcolor='black', color='black', fill_empty=0, length=5.8, linewidth=1)
##        #key = plt.barbs(0030, 227, 10*np.cos(60), -10*np.sin(60), 10*1.94, label='10 kts', barbcolor='black',
##	    flagcolor='black', color='black', fill_empty=0, length=5.8, linewidth=1.4)
##        plt.text(0150, 223, '10 kts', fontsize=12, bbox=dict(facecolor='none', edgecolor='none', alpha=0.8))
#
#        # prettifying the plots
#
#        if np.nanmax(w)-1 > 10:
#            cb_pad = -83
#        else:
#            cb_pad = -75
#
#        cb = plt.colorbar(format='%.1f', pad=0.05)
#        cb.set_label(r'1-Hz V_h wind speed (filled, m s$^{-1}$)', labelpad=cb_pad, fontsize=colorbar_fs)
#        ax.set_xlabel('Time (UTC)', fontsize=label_fs)
#        ax.set_ylabel(r'Z (m $AGL$)', fontsize=label_fs)
#        cb.ax.tick_params(labelsize=colorbar_fs)
#        plt.tick_params(axis='both', which='major', labelsize=tick_fs)
#        ax.xaxis.set_major_formatter(FormatStrFormatter('%04d'))
#        plt.suptitle(day + ' '  +  month + ' ' + year +' '+ site, fontsize=label_fs, x=0.45, y=1)
#        plt.title(latlon + ' at ' + elev, fontsize=colorbar_fs, ha='center')
##        plt.grid()
#        plt.xlim(0,end_time)
#        plt.ylim(30,230)
#
#        savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.V_h_WindsTimeHeightContour.png', bbox_inches='tight')
#
#        #vertical
#        contour_levels = np.arange(-10,10, 0.25)
##        contour_levels = np.arange(-1.1,1.1,0.2)
#        
#        barb_stagger = 20
#
##        CS = plt.contourf(timeUTC, z, fixed_WS, contour_levels, extend='max', cmap='
#')
##        CS = plt.contourf(timeUTC, z, np.transpose(w), contour_levels, extend='max', cmap='bwr')
##        B = plt.barbs(timeUTC[::barb_stagger], z, -v[:,::barb_stagger]*1.94, -u[:,::barb_stagger]*1.94,
##            barbcolor='black', flagcolor='black', color='black', fill_empty=0, length=5.8, linewidth=1)
####        key = plt.barbs(0030, 227, 10*np.cos(60), -10*np.sin(60), 10*1.94, label='10 kts', barbcolor='black',
##	    flagcolor='black', color='black', fill_empty=0, length=5.8, linewidth=1.4)
##        plt.text(0150, 223, '10 kts', fontsize=12, bbox=dict(facecolor='none', edgecolor='none', alpha=0.8))
#
#        # prettifying the plots
#
##        if np.nanmax(fixed_w)-1 > 10:
##            cb_pad = -83
##        else:
##            cb_pad = -75
#
#        cb = plt.colorbar(format='%.1f', pad=0.05)
#        #cb.set_label(r'2-min avg horizontal wind speed (filled, m s$^{-1}$)', labelpad=cb_pad, fontsize=colorbar_fs)
#        cb.set_label(r'1-Hz w wind speed (filled, m s$^{-1}$)', labelpad=cb_pad, fontsize=colorbar_fs)
#        ax.set_xlabel('Time (UTC)', fontsize=label_fs)
#        ax.set_ylabel(r'Z (m $AGL$)', fontsize=label_fs)
#        cb.ax.tick_params(labelsize=colorbar_fs)
#        plt.tick_params(axis='both', which='major', labelsize=tick_fs)
#        ax.xaxis.set_major_formatter(FormatStrFormatter('%04d'))
#        plt.suptitle(day + ' '  +  month + ' ' + year +' '+ site, fontsize=label_fs, x=0.45, y=1)
#        plt.title(latlon + ' at ' + elev, fontsize=colorbar_fs, ha='center')
##        plt.grid()
#        plt.xlim(0,2401)
#        plt.ylim(30,230)
#
#        savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.WindsTimeHeightContour.png', bbox_inches='tight')
##        savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.RTDw_WindsTimeHeightContour.png', bbox_inches='tight')
#
## Now plot a time series at one specific height
#        desired_height = 100.
#        this_height_index = (np.where(z > desired_height))[0] -1 
#        this_height_index = this_height_index[0]
#        print(z[this_height_index])
#        plt.plot(timeUTC,transpose_V_h[:,this_height_index])
#        plt.xlabel('Time (UTC)', fontsize=label_fs)
#        plt.ylabel(r'Vhm (m s$^{-1}$)', fontsize=label_fs)
#        plt.tick_params(axis='both', which='major', labelsize=tick_fs)
#        ax.xaxis.set_major_formatter(FormatStrFormatter('%04d'))
#        plt.suptitle(str(z[this_height_index]) + ' m winds on ' + day + ' '  +  month + ' ' + year +' '+ site, fontsize=label_fs, x=0.45, y=1)
#        plt.title(latlon + ' at ' + elev, fontsize=colorbar_fs, ha='center')
#        plt.grid()
#        plt.xlim(0,2401)
#        plt.ylim(0,20)
#        plt.show
#        plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.WindsTimeSeries' + str(z[this_height_index]) + 'm.png', 
#            dpi=300)
##        savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.WindsTimeSeries'+str(z[this_height_index])+'m.png', bbox_inches='tight')
