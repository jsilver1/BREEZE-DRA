#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed 4 Mar 2020 

@author: jlundqui 
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math
from matplotlib.ticker import FormatStrFormatter
import glob
import os
import ftplib
import netCDF4
from netCDF4 import Dataset
import pytz, datetime
from datetime import datetime



##-------------------HELPER FUNCTIONS------------------
##-----------------------------------------------------
def timeStrToMin(x):
	time = x.split(':')
	time = [float(x) for x in time]
	tMins = time[0]*60 + time[1]
	return tMins

#def timeMinToStr(x):
#	hrs = x /60
#	mins= x % 60
#	h_s = str(hrs)
#	m_s = str(mins)
#	if(len(h_s) < 2):
#		h_s = '0'+h_s
#	if(len(m_s) < 2):
#		m_s = '0'+m_s
#	return h_s+':'+m_s+':'+'00'

def timeStrToFloat (x):	
	time = x.split(':')			
	time = [float(x) for x in time]        
	float_time_hr = time[0] + time[1]/60 + time[2]/3600			
	return float_time_hr        



def fixWDwrtWS(WD_matrix, WS_matrix):
	newWD_matrix = WD_matrix
	for r in range(0,10):
		for c in range(0,720):
			if math.isnan(WS_matrix[r,c]) and (WD_matrix[r,c] >= 0.0):
				newWD_matrix[r,c] = np.NAN
	return newWD_matrix

##---------------** END **-----------------------------
##-----------------------------------------------------

##-----------------------------------------------------
##              MAIN PROGRAM 
##-----------------------------------------------------

#Following data preparation guide at https://docs.google.com/document/d/15mo5ezj1hlL6oc4__ekerGuJa65h0PHzPlzaAxye54U/edit#heading=h.e8poq7bxhhtz


##-----------------------------------------------------
### Choose one of the following paragraphs to select which lidar files.
path_in = '/Users/jlundqui/Documents/lidar/ISARRA_2018/WC_68/RTD/'
#path_in = '/Users/jlundqui/Documents/lidar/ISARRA_2018/WC_49/'
path_out = path_in
file_count = 7 #7

#path_in = '/Users/jlundqui/Documents/lidar/ISARRA_2018/WC_49/'
#path_out = path_in
#file_count = 7
##-----------------------------------------------------

sorted_files = sorted(glob.iglob(path_in + 'Converted_WLS7-00*_2018_07_14__00_00_00.rtd'), reverse=True) #key=os.path.getctime,  
sorted_files = sorted(glob.iglob(path_in + 'Converted_WLS7-00*.rtd'), reverse=True) #key=os.path.getctime,  
last_files = [sorted_files[i] for i in np.arange(file_count)]

# read file and retain all data from each file 
# file include: lidar, fname, time_array, time_UTC, Azi, V_h

nfile = np.arange(file_count)

for nfile in nfile:
    fname = last_files[nfile].split('/')[-1]
    
    f = open(path_in + fname, encoding='iso-8859-1')  # thanks Leosphere  
    lines=[]
    # Read from File # This line causes problems although can read in data OK otherwise.
    for line in f: 
        lines.append(line.split())
    
    #header = lines[0:55]
    GPS_Localisation = ' '.join(lines[5])
    ScanAngle = lines[9]   
    Number_of_averaged_shots = lines[10]
    RollAngle = lines[11]
    HeadingAngle = lines[12]
    Altitudes = ' '.join(lines[13]) 
    Pitch_angle = lines[14]
    Wavelength = lines[19]
    Algorithm = lines[24]
    MAOfrequency = lines[25]
    CutOfffrequency = lines[26]
    WindowLength = lines[27] 
    IndexRange = lines[28]
    PathLaserPulse = ' '.join(lines[29])
    NumberOfSamplesLaserPulse = lines[30]
    
    BeginIndex_LaserPulse = lines[31]
    BeginIndex_NoiseReference= lines[32]
    NumberOfNoiseWindowsByProfile= lines[33]
    VrThreshold = ' '.join(lines[34])  
    SigmaFreqThreshold= ' '.join(lines[35]) 
    SamplingInterval= lines[38]
    NumberOfSamples= lines[39] #1024
    VerticalCoupling=' '.join(lines[40])  #AC, 50 Ohm
    Offset=lines[41]
    FullScale= lines[42] 
    NumberOfSegments=lines[43] #100
    TriggerSource=lines[44] # External
    TriggerCoupling=' '.join(lines[45])   #DC, 50 Ohm (Ext. trig. only)
    TriggerSlope=lines[46] #Positive
    TriggerLevel1=lines[47] #3000
    TriggerLevel2=lines[48] #0
    DelayLine=lines[49] #4.000000E-7
    AbsoluteInitialPosition= lines[50] #122040
    RelativeInitialPosition= lines[51]
    InitialDateTime= ' '.join(lines[52])  #14/07/2018 00:00:00.68
    Gain= lines[53] #32.797000
    InitialLD1 = lines[54] #(mA)=IC1=320
    InitialLD2= lines[55] #IC2=1650
    
#    1 HeaderLength=55
#    2 Version=3.1.66
#    3 ID System=WLS7-0068
#    4 ID Client=University of Colorado
#    5 Localisation=RNRG courtyard
#    6 GPS Localisation=38°05'55.57"N 106°10'13.15"W 2387.2m
#    7 Comments=v1+ update test
#    8 Measurements informations :
#    9 ********************
#   10 ScanAngle(°)=27.86
#   11 NumberOfAveragedShots=10000
#   12 RollAngle(°)=0.40
#   13 HeadingAngle(°)=-17.80
#   14 Altitudes(m)=   40      60      80      100     120     140     160     180     200     220
#   15 PitchAngle(°)=-0.20
#   16 CNRThreshold=-22
#   17 WiperCNRThreshold=-19.0
#   18 WiperAltitude(m)=100.0
#   19 WiperDuration(ms)=1000.0
#   20 Wavelength(nm)=1543.00
#   21 Angle BetweenTwoPositions(°)=90
#   22 DirectionOffset(°)=0.000
#   23 Algorithm Parameters :
#       
#   25 Algorithm=MLE
#   26 MAOFrequency(Hz)=68000000.000
#   27 CutOffFrequency(Hz)=90000000.000
#   28 WindowLength(s)=0.000000E+0
#   29 IndexRange0=70
#   30 PathLaserPulse=C:\Program Files\Leosphere\windsoft\pulse_laser.sig
#   31 NumberOfSamples_LaserPulse=74
#   32 BeginIndex_LaserPulse=0
#   33 BeginIndex_NoiseReference=0
#   34 NumberOfNoiseWindowsByProfile=1
#   35 VrThreshold (m/s)=)1.700
#   36 SigmaFreqThreshold (m/s)=)0.750
#   37 Acquisition Parameters :
#
#   39 SamplingInterval=4.000000E-9
#   40 NumberOfSamples=1024
#   41 VerticalCoupling=AC, 50 Ohm
#   42 Offset=0.000
#   43 FullScale=0.200
#   44 NumberOfSegments=100
#   45 TriggerSource=External
#   46 TriggerCoupling=DC, 50 Ohm (Ext. trig. only)
#   47 TriggerSlope=Positive
#   48 TriggerLevel1=3000
#   49 TriggerLevel2=0
#   50 DelayLine=4.000000E-7
#   51 AbsoluteInitialPosition(°)=122040
#   52 RelativeInitialPosition(°)=0
#   53 InitialDate/Time=14/07/2018 00:00:00.68
#   54 Gain=32.797000
#   55 InitialLD1(mA)=IC1=320
#   56 InitialLD2(mA)=IC2=1650
#       
    
    lines = lines[57:]
    
    #check which site - both sites at Saguache for the first day
    #DPLR1:	CU Doppler Lidar 1 = WC68 since no need to shift time
    #DPLR2:	CU Doppler Lidar 2 = WC49 since need to shift time by 20ish minutes

    if fname[15:19] == '0068':
        lidar = 'WC68'
        tag = '1'
        latlon = r"38.09877$^{\circ}$N, -106.17028$^{\circ}$W"
        elev = '2388 m'
        site = 'Saguache'
        print(site)
    elif (fname[15:19] == '0049') and (fname[28:30] == '14'):
        lidar = 'WC49'
        tag = '2'
        latlon = r"38.09877$^{\circ}$N, -106.17028$^{\circ}$W"
        elev = '2388 m'
        site = 'Saguache'
        print(site)
    elif (fname[15:19] == '0049') : # not on the 14th
        lidar = 'WC49'
        tag = '2'
        latlon = r"37.99794$^{\circ}$N, -105.91199$^{\circ}$W"
        elev = '2308 m' ### ???? 37.99794 N, 105.91199 W
        site = 'Moffat School'
        print(site)

    if fname[10:14] == 'WLS7':
        print(fname)

        # Convert to numpy format array
        data = np.array(lines)

        if fname[25:27] == '01':
            month = 'Jan'
        elif fname[25:27] == '07':
            month = 'Jul'
        else:
            raise TypeError('That month (' + fname[25:27]  +  ') is not within the calendar year!')

        year = fname[20:24]
        day = fname[28:30]
        mon = fname[25:27]
        hour = fname[32:34]
        min = fname[35:37]

        date_str = fname[20:31]

        print(np.shape(data))
        
        time_str = (data[:,1])
        time_array = np.array([timeStrToFloat(x) for x in time_str.tolist()])
        
        
        complete_str = [ date_str + t for t in time_str]

        
        utc_time = [ datetime.strptime(t, "%Y_%m_%d_%H:%M:%S.%f") for t in complete_str]
        epoch_time = [ (t - datetime(1970, 1, 1)).total_seconds() for t in utc_time ]

        # WC49 was 20ish minutes fast. Lots of work to figure out offset was 0.34 hr
        if fname[15:19] == '0049':
            print('shifting time for WC 49')
            #epoch_time = epoch_time - 0.34*60*60
            epoch_time = [ t - 0.34*60*60 for t in epoch_time ]

#        end_time = 20   #Just for the intercomparison day at Saguache
#        last_time_index = np.min(np.where(time_array > 20)) - 1
#        data = data[0:last_time_index,:]
        
#        time_array = time_array[0:last_time_index]
#        time_str = time_str[0:last_time_index]
        
        beam_str = data[:,2]
        justdata = data[:,5:]

        n_lines = np.shape(justdata)[0]
        n_heights = np.shape(justdata)[1]/8

        justdata_shaped = np.reshape(justdata,(int(n_lines),int(n_heights),8))
        this_beam = beam_str.astype(np.int) #jkl
        this_CNR = justdata_shaped[:,:,0].astype(np.float) #hard to evaluate
        this_RWS = justdata_shaped[:,:,1].astype(np.float)
        this_RWSD = justdata_shaped[:,:,2].astype(np.float)
        this_V_h = justdata_shaped[:,:,3].astype(np.float)
        this_Azi = justdata_shaped[:,:,4].astype(np.float)
        this_u = justdata_shaped[:,:,5].astype(np.float)
        this_v = justdata_shaped[:,:,6].astype(np.float)
        this_w = justdata_shaped[:,:,7].astype(np.float)
                
        #Need to replace bad data values with -9999.
        this_CNR[np.where(this_CNR > 0)] = -9999.0
        this_RWS[np.where(this_RWS > 50)] = -9999.0
        this_RWSD[np.where(this_RWSD > 10)] = -9999.0
        this_V_h[np.where(this_V_h < -10)] = -9999.0
        this_Azi[np.where(this_Azi < 0)] = -9999.0
        this_u[np.where(this_u < -30)] = -9999.0 # assume horiz winds > 30 m/s are not real
        this_v[np.where(this_v < -30)] = -9999.0 # assume horiz winds > 30 m/s are not real
        this_w[np.where(this_w < -20)] = -9999.0 # assume vert winds > 10 m/s are not real

        # PLOTTING
    
        z = np.array([40,60,80,100,120,140,160,180,200,220])
        #timeUTC = np.linspace(0,2401,720)
#        timeUTC = np.linspace(0,end_time,n_lines)

        offset = -0.34  # updated 4 March 2020, only use for WC49

#DPLR1:	CU Doppler Lidar 1 = WC68 since no need to shift time
#DPLR2:	CU Doppler Lidar 2 = WC49 since need to shift time by 20ish minutes
        #dataset = Dataset('UCB.DPLR'+tag+'.a1.20180714.000000.cdf','w',format='NETCDF4_CLASSIC')
        outfilename = 'UCB.DPLR'+tag+'.a2.'+year+mon+day+'.000000.cdf'
        dataset = Dataset(outfilename,'w',format='NETCDF4_CLASSIC')
#a1: 	Calibration factors applied and converted to geophysical units
#b1: 	QC checks applied to measurements to ensure that they are “in bounds”.  Missing data points or those with bad values should be set to -9999.9

        height = dataset.createDimension('height', 10)
        time = dataset.createDimension('time', None)


## Create coordinate variables for 4-dimensions
        times = dataset.createVariable('time', np.float64, ('time',))
        heights = dataset.createVariable('height', np.int32, ('height',))
        beams = dataset.createVariable('beam', np.int32, ('time',)) #jkl 
        wspd = dataset.createVariable('wspd', np.float32,('time','height'))
        wdir = dataset.createVariable('wdir', np.float32,('time','height'))
        CNR = dataset.createVariable('CNR', np.float32,('time','height'))  
        RWS = dataset.createVariable('RWS', np.float32,('time','height'))  
        RWSD = dataset.createVariable('RWSD', np.float32,('time','height'))  
        u = dataset.createVariable('u', np.float32,('time','height'))  
        v = dataset.createVariable('v', np.float32,('time','height'))  
        w = dataset.createVariable('w', np.float32,('time','height'))  


#import time
## Global Attributes
        dataset.description = 'CU profiling lidar observations from '+lidar
#        dataset.history = 'Created ' + time.ctime(time.time())
        dataset.source = 'Converted RTD files from Julie.Lundquist@colorado.edu'
        dataset.latlon = latlon
        dataset.msl = elev
        dataset.site = site
        dataset.GPS_Localisation = GPS_Localisation
        dataset.ScanAngle = ScanAngle   
        dataset.Number_of_averaged_shots = Number_of_averaged_shots
        dataset.RollAngle = RollAngle 
        dataset.HeadingAngle = HeadingAngle #lines[12]
        dataset.Altitudes = Altitudes #lines[13]
        dataset.Pitch_angle = Pitch_angle #lines[14]
        dataset.Wavelength = Wavelength #lines[19]
        dataset.Algorithm = Algorithm #lines[24]
        dataset.MAOfrequency = MAOfrequency #lines[25]
        dataset.CutOfffrequency = CutOfffrequency #lines[26]
        dataset.WindowLength = WindowLength #lines[27] 
        dataset.IndexRange = IndexRange #lines[28]
        dataset.PathLaserPulse = PathLaserPulse #lines[29]
        dataset.NumberOfSamplesLaserPulse = NumberOfSamplesLaserPulse #lines[30]
        dataset.BeginIndex_LaserPulse = BeginIndex_LaserPulse #lines[31]
        dataset.BeginIndex_NoiseReference= BeginIndex_NoiseReference # lines[32]
        dataset.NumberOfNoiseWindowsByProfile= NumberOfNoiseWindowsByProfile #lines[33]
        dataset.VrThreshold = VrThreshold #lines[34]
        dataset.SigmaFreqThreshold= SigmaFreqThreshold #lines[35]
        dataset.SamplingInterval= SamplingInterval #lines[38]
        dataset.NumberOfSamples= NumberOfSamples #lines[39] #1024
        dataset.VerticalCoupling= VerticalCoupling #lines[40] #AC, 50 Ohm
        dataset.Offset= Offset #lines[41]
        dataset.FullScale= FullScale #lines[42] 
        dataset.NumberOfSegments= NumberOfSegments #lines[43] #100
        dataset.TriggerSource= TriggerSource #ines[44] # External
        dataset.TriggerCoupling= TriggerCoupling #lines[45] #DC, 50 Ohm (Ext. trig. only)
        dataset.TriggerSlope= TriggerSlope #lines[46] #Positive
        dataset.TriggerLevel1= TriggerLevel1 #lines[47] #3000
        dataset.TriggerLevel2= TriggerLevel2 #lines[48] #0
        dataset.DelayLine= DelayLine #lines[49] #4.000000E-7
        dataset.AbsoluteInitialPosition= AbsoluteInitialPosition #lines[50] #122040
        dataset.RelativeInitialPosition= RelativeInitialPosition #lines[51]
        dataset.InitialDateTime= InitialDateTime #lines[52] #14/07/2018 00:00:00.68
        dataset.Gain= Gain #lines[53] #32.797000
        dataset.InitialLD1 = InitialLD1 #lines[54] #(mA)=IC1=320
        dataset.InitialLD2= InitialLD2 #lines[55] #IC2=1650

## Variable Attributes
#latitudes.units = 'degree_north'
#longitudes.units = 'degree_east'
        times.units = 'sec'
        times.description = 'seconds since epoch (00:00:00, 1 January 1970)'
        heights.units = 'm'
        heights.description = 'center altitude of the 20-m deep measurement volume'
        beams.units = 'deg'  #jkl
        beams.description = 'cardinal direction of beam' #jkl
        wspd.units = 'm s-1'
        wspd.description = 'horizontal wind speed'
        wdir.units = 'deg'
        wdir.description = 'wind direction, meteorological units, 0 = from the north, 90 = from the east'
        CNR.units = 'dB'
        CNR.description = 'Carrier to Noise ratio (dB) in the beam line-of-sight'
        RWS.units = 'Radial Wind Speed (m s-1)'
        RWS.description = 'Radial Wind Speed'
        RWSD.units = 'm s-1' 
        RWSD.description = 'Averaged Doppler Spectrum width converted into m s-1'
        u.units = 'm s-1'
        u.description = 'zonal wind, west to east'
        v.units = 'm s-1'
        v.description = 'meridional wind, south to north'
        w.units = 'm s-1'
        w.description = 'vertical velocity, positive pointing up'
#times.calendar = 'gregorian'


        times[:] = epoch_time
        heights[:] = z
        beams[:] = this_beam #jkl
        wspd[:] = this_V_h
        wdir[:] = this_Azi
        CNR[:] = this_CNR
        RWS[:] = this_RWS
        RWSD[:] = this_RWSD
        u[:] = - this_v # convert from Leosophere convention to meteorological convention
        v[:] = - this_u # convert from Leosphere convention to meteorological convention
        w[:] = - this_w # convert from Leosphere convention to meteorological convention
# close the file.
        dataset.close()
        print('Done with '+outfilename)
        
print('Done with all files')        
#print '*** SUCCESS writing example file simple_xy.nc!'

#U = dataset.createDimension('U',)
#Critical (as appropriate):
#MSL Altitude of sensor (m)
#Lat of platform (deg)
#Lon of platform (deg)
#Strongly Desired:
#Temperature (K)
#Pressure (hPa)
#Relative Humidity (%)
#Wind Speed (m/s) [for surface met and radiosonde]
#Wind Direction (deg) [for surface met and radiosonde]
#U wind (m/s) [for Doppler lidar]
#V wind (m/s) [for Doppler lidar]
#W wind (m/s) [for Doppler lidar]
#MWR brightness temperatures (K)
#MWR IR sky temperature (K)
#MWR Precipitable Water (mm)
#MWR Liquid Water Path (mm)
#AERI longwave spectral radiance

#Metadata should provide information that is important in understanding or interpreting the data stream but are not considered significant for naming purposes. Examples of information that could be included in global metadata for a given file includes:
#Location of sensor/platform (if stationary platform)
#QC checks and flags applied
#Calibration procedural information as appropriate
#PI Contact information
#Additionally, for individual variables, information should be included to help the user understand how the measurement was obtained and what it represents.  This could include: 
#Orientation: downwelling, upwelling, or dependent on installation as appropriate.
#Missing data value applied to a given variable (e.g. -9999.9)
#Key information to characterize the measurement
#The instrument/sensor used for the measurement (occasionally important especially if it comes from a data stream containing results from several instruments).
#Time interval information (e.g., averaging time and measurement intervals).
#The units of the measurement
#An indication that the data is a best estimate data or a calculated value data stream. Unless indicated otherwise, it is implicit that the measurement is observed.
