#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 10 15:55:09 2017

@author: jeto6273; 

"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import math
from matplotlib.ticker import FormatStrFormatter
import glob
import os
import ftplib
#from waveletFunctions import wavelet, wave_signif


##-------------------HELPER FUNCTIONS------------------
##-----------------------------------------------------
def timeStrToMin(x):
	time = x.split(':')
	time = [float(x) for x in time]
	tMins = time[0]*60 + time[1]
	return tMins

def timeMinToStr(x):
	hrs = x /60
	mins= x % 60
	h_s = str(hrs)
	m_s = str(mins)
	if(len(h_s) < 2):
		h_s = '0'+h_s
	if(len(m_s) < 2):
		m_s = '0'+m_s
	return h_s+':'+m_s+':'+'00'

def timeStrToFloat (x):	
	time = x.split(':')			
	time = [float(x) for x in time]
	if(time[0] == 0.0 and time[1] == 0.0):
		time[0] = 24.0
	totalHours = time[0] + time[1]/60.0 

def fixMissingTime(matrix,time_array_str):
	# We know that there has to be 720 columns	
	n_times = time_array_str.shape
	if n_times[0] == 720:
		#print("Already has complete data !! Exiting ")
		return matrix				
	# n_rows,n_cols = matrix.shape	
	st_time = 2
	index = 0
	hit_count = 0
	final_matrix = np.empty((10,721-n_times[0]))
	final_matrix[:] = np.NAN
	while st_time < 1441:				
		st_time_str = timeMinToStr(st_time)
		if st_time_str in time_array_str:
			hit_count = hit_count+1			
			src_index = np.where(time_array_str==st_time_str)[0][0]
			# print(st_time_str,src_index,index)
			# print(matrix[:,src_index])
			final_matrix = np.insert(final_matrix,index, matrix[:,src_index],axis=1)			
		st_time = st_time + 2
		index = index + 1
	return final_matrix[:,0:720]

def fixWDwrtWS(WD_matrix, WS_matrix):
	newWD_matrix = WD_matrix
	for r in range(0,10):
		for c in range(0,720):
			if math.isnan(WS_matrix[r,c]) and (WD_matrix[r,c] >= 0.0):
				newWD_matrix[r,c] = np.NAN
	return newWD_matrix

##---------------** END **-----------------------------
##-----------------------------------------------------

##-----------------------------------------------------
##              MAIN PROGRAM 
##-----------------------------------------------------


path_in = '/Users/jlundqui/Documents/Proposals/Active/DOE_WFIP/MountainWaves/'
path_out = path_in

file_count = 10
sorted_files = sorted(glob.iglob(path_in + 'WLS7-0068*.sta'), reverse=True) #key=os.path.getctime,  
last_files = [sorted_files[i] for i in np.arange(file_count)]

# read file, write text file of wind speed at 80-m winds for last 5 files (days)

nfile = np.arange(file_count)

for nfile in nfile:
    fname = last_files[nfile].split('/')[-1]

    f = open(path_in + fname, encoding='iso-8859-1')  # thanks Leosphere  
    lines=[]
    # Read from File # This line causes problems although can read in data OK otherwise.
    for line in f: 
        lines.append(line.split())
        
    lines = lines[57:]
    # JKL: write a clause here to give lat/long for the right windcube
    #latlon = r"45.5899$^{\circ}$N, -120.672044$^{\circ}$W"
    #elev = '455 m'
    #site = 'Wasco'
    
    #check which site
    if fname[5:9] == '0068':
        latlon = r"45.5899$^{\circ}$N, -120.672044$^{\circ}$W"
        elev = '455 m'
        site = 'Wasco'
    elif fname[5:9] == '0049':
        latlon = r"45.5534$^{\circ}$N, -122.386995$^{\circ}$W"
        elev = '12 m'
        site = 'Troutdale'
    elif fname[5:9] == '0231':
        latlon = r"45.515620$^{\circ}$N, -120.780007^{\circ}$W"
        elev = '728 m'
        site = 'Gordon Ridge'
          

    # check we have a normal full day file
    #if fname[-6:-4] == '00':
    if fname[:4] == 'WLS7':
        print(fname)

        # Convert to numpy format array
        data = np.array(lines)

        if fname[15:17] == '01':
            month = 'Jan'
        elif fname[15:17] == '02':
            month = 'Feb'
        elif fname[15:17] == '03':
            month = 'Mar'
        elif fname[15:17] == '04':
            month = 'Apr'
        elif fname[15:17] == '05':
            month = 'May'
        elif fname[15:17] == '06':
            month = 'Jun'
        elif fname[15:17] == '07':
            month = 'Jul'
        elif fname[15:17] == '08':
            month = 'Aug'
        elif fname[15:17] == '09':
            month = 'Sep'
        elif fname[15:17] == '10':
            month = 'Oct'
        elif fname[15:17] == '11':
            month = 'Nov'
        elif fname[15:17] == '12':
            month = 'Dec'
        else:
            raise TypeError('That month (' + fname[15:17]  +  ') is not within the calendar year!')

        year = fname[10:14]
        day = fname[18:20]
        mon = fname[15:17]
        hour = fname[22:24]
        min = fname[25:27]

        time_str = data[:,1]
        time_array = np.array([timeStrToFloat(x) for x in time_str.tolist()])

        justdata = data[:,4:]

        n_lines = np.shape(justdata)[0]
        n_heights = np.shape(justdata)[1]/18

        justdata_shaped = np.reshape(justdata,(int(n_lines),int(n_heights),18))
        Vhm = justdata_shaped[:,:,0].astype(np.float) #hard to evaluate
        dVh1 = justdata_shaped[:,:,1].astype(np.float)
        VhMax = justdata_shaped[:,:,2].astype(np.float)
        VhMin = justdata_shaped[:,:,3].astype(np.float)
        Azim = justdata_shaped[:,:,4].astype(np.float)
        um = justdata_shaped[:,:,5].astype(np.float)
        du = justdata_shaped[:,:,6].astype(np.float)
        vm = justdata_shaped[:,:,7].astype(np.float)        
        dv = justdata_shaped[:,:,8].astype(np.float) #hard to evaluate
        wm = justdata_shaped[:,:,9].astype(np.float)
        dw = justdata_shaped[:,:,10].astype(np.float)
        CNRm = justdata_shaped[:,:,11].astype(np.float)
        dCNR = justdata_shaped[:,:,12].astype(np.float)
        CNRmax = justdata_shaped[:,:,13].astype(np.float)
        CNRmin = justdata_shaped[:,:,14].astype(np.float)
        spectral_broadening = justdata_shaped[:,:,15].astype(np.float)
        dspectral_broadening = justdata_shaped[:,:,16].astype(np.float)
        Avail = justdata_shaped[:,:,17].astype(np.float)


        # Calculate WS Wind Speed for each height and stack them into matrix

#
#        WS_matrix = np.vstack((WS_40m,WS_60m,WS_80m,WS_100m,WS_120m,WS_140m,WS_160m,WS_180m,WS_220m,WS_220m))
#        fixed_WS = fixMissingTime(WS_matrix,time_str)
#
#        u_matrix = np.vstack((u_40m,u_60m,u_80m,u_100m,u_120m,u_140m,u_160m,u_180m,u_220m,u_220m))
#        fixed_u = fixMissingTime(u_matrix,time_str)
#
#        v_matrix = np.vstack((v_40m,v_60m,v_80m,v_100m,v_120m,v_140m,v_160m,v_180m,v_220m,v_220m))
#        fixed_v = fixMissingTime(v_matrix,time_str)
#        
#        w_matrix = np.vstack((w_40m,w_60m,w_80m,w_100m,w_120m,w_140m,w_160m,w_180m,w_220m,w_220m))
#        fixed_w = fixMissingTime(w_matrix,time_str)


#	# Fill in missing times at end of file
#        while len(fixed_WS[0,:]) < 720:
#                a = np.array([[np.nan],[np.nan],[np.nan],[np.nan],[np.nan],[np.nan],[np.nan],[np.nan],[np.nan],[np.nan]])
#                fixed_WS = np.hstack((fixed_WS, a))
#                fixed_w = np.hstack((fixed_w, a))
# 
        # Write out time series of hubheight winds at 80-m, hard-wired to 80m
        
        Vhm_80m = Vhm[:,2]
        
        #identify nans and replace with linear interpolation
        
        baddata = np.where(np.isnan(Vhm_80m))
        
#        for i in baddata:
#            before = np.max(np.where(np.isnan(Vhm_80m) = false and ) )
        
        fileobj = open(path_in+fname+'80mVhm.txt', 'w')
        Vhm_80m_str = [str(i)+'\n' for i in Vhm_80m]
        fileobj.writelines(Vhm_80m_str)
        fileobj.close()
        
            # Write out time series of hubheight vertical velocity at 80-m, hard-wired to 80m
        
        wm_80m = wm[:,2]
        
        #identify nans and replace with linear interpolation
        
        
#        for i in baddata:
#            before = np.max(np.where(np.isnan(Vhm_80m) = false and ) )
        
        fileobj = open(path_in+fname+'80mwm.txt', 'w')
        wm_80m_str = [str(i)+'\n' for i in wm_80m]
        fileobj.writelines(wm_80m_str)
        fileobj.close()
    
        # PLOTTING
    
        z = np.array([40,60,80,100,120,140,160,180,200,220])
        timeUTC = np.linspace(0,2401,720)

        fig = plt.figure(figsize=[14,7])
        ax = plt.subplot(111)

        # fontsizes:
        colorbar_fs = 16
        label_fs = 24
        tick_fs = 16
        key_fs = 14

        #horizontal
        contour_levels = np.arange(0, np.ceil(np.nanmax(Vhm)), 0.5) #16?
        #contour_levels = np.arange(np.floor(np.nanmin(fixed_w)), np.ceil(np.nanmax(fixed_w)), 0.25)

        #vertical
#        contour_levels = np.arange(-np.ceil(np.nanmax(np.abs(fixed_w))), np.ceil(np.nanmax(np.abs(fixed_w))), 0.25)
#        contour_levels = np.arange(-1.1,1.1,0.2)
        
        barb_stagger = 20

        #CS = plt.contourf(timeUTC, z, fixed_WS, contour_levels, extend='max', cmap='viridis')
        CS = plt.contourf(timeUTC, z, np.transpose(Vhm), contour_levels, extend='max', cmap='viridis')
        B = plt.barbs(timeUTC[::barb_stagger], z, -np.transpose(vm)[:,::barb_stagger]*1.94, 
            -np.transpose(um)[:,::barb_stagger]*1.94,
            barbcolor='black', flagcolor='black', color='black', fill_empty=0, length=5.8, linewidth=1)
#        key = plt.barbs(0030, 227, 10*np.cos(60), -10*np.sin(60), 10*1.94, label='10 kts', barbcolor='black',
#	    flagcolor='black', color='black', fill_empty=0, length=5.8, linewidth=1.4)
#        plt.text(0150, 223, '10 kts', fontsize=12, bbox=dict(facecolor='none', edgecolor='none', alpha=0.8))

        # prettifying the plots

        if np.nanmax(Vhm)-1 > 10:
            cb_pad = -83
        else:
            cb_pad = -75

        cb = plt.colorbar(format='%.1f', pad=0.05)
        cb.set_label(r'2-min avg horizontal wind speed (filled, m s$^{-1}$)', labelpad=cb_pad, fontsize=colorbar_fs)
        #cb.set_label(r'2-min avg vertical wind speed (filled, m s$^{-1}$)', labelpad=cb_pad, fontsize=colorbar_fs)
        ax.set_xlabel('Time (UTC)', fontsize=label_fs)
        ax.set_ylabel(r'Z (m $AGL$)', fontsize=label_fs)
        cb.ax.tick_params(labelsize=colorbar_fs)
        plt.tick_params(axis='both', which='major', labelsize=tick_fs)
        ax.xaxis.set_major_formatter(FormatStrFormatter('%04d'))
        plt.suptitle(day + ' '  +  month + ' ' + year +' '+ site, fontsize=label_fs, x=0.45, y=1)
        plt.title(latlon + ' at ' + elev, fontsize=colorbar_fs, ha='center')
        plt.grid()
        plt.xlim(0,2401)
        plt.ylim(30,230)

        savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.WindsTimeHeightContour.png', bbox_inches='tight')
        #savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.VertWindsTimeHeightContour.png', bbox_inches='tight')

# Now plot a time series at one specific height
        desired_height = 100.
        this_height_index = (np.where(z > desired_height))[0] -1 
        this_height_index = this_height_index[0]
        print(z[this_height_index])
        plt.plot(timeUTC,Vhm[:,this_height_index])
        plt.xlabel('Time (UTC)', fontsize=label_fs)
        plt.ylabel(r'Vhm (m s$^{-1}$)', fontsize=label_fs)
        plt.tick_params(axis='both', which='major', labelsize=tick_fs)
        ax.xaxis.set_major_formatter(FormatStrFormatter('%04d'))
        plt.suptitle(str(z[this_height_index]) + ' m winds on ' + day + ' '  +  month + ' ' + year +' '+ site, fontsize=label_fs, x=0.45, y=1)
        plt.title(latlon + ' at ' + elev, fontsize=colorbar_fs, ha='center')
        plt.grid()
        plt.xlim(0,2401)
        plt.ylim(0,20)
        plt.show
        plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.WindsTimeSeries' + str(z[this_height_index]) + 'm.png', 
            dpi=300)
#        savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.WindsTimeSeries'+str(z[this_height_index])+'m.png', bbox_inches='tight')

#Now try to do a wavelet analysis on this time series.
        


