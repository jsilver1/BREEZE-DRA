#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tues Nov 6 2018 

@author: jlundqui modifying jeto code
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math
from matplotlib.ticker import FormatStrFormatter
import glob
import os
import ftplib
import netCDF4


##-------------------HELPER FUNCTIONS------------------
##-----------------------------------------------------
def timeStrToMin(x):
	time = x.split(':')
	time = [float(x) for x in time]
	tMins = time[0]*60 + time[1]
	return tMins

#def timeMinToStr(x):
#	hrs = x /60
#	mins= x % 60
#	h_s = str(hrs)
#	m_s = str(mins)
#	if(len(h_s) < 2):
#		h_s = '0'+h_s
#	if(len(m_s) < 2):
#		m_s = '0'+m_s
#	return h_s+':'+m_s+':'+'00'

def timeStrToFloat (x):	
	time = x.split(':')			
	time = [float(x) for x in time]        
	float_time_hr = time[0] + time[1]/60 + time[2]/3600			
	return float_time_hr        



def fixWDwrtWS(WD_matrix, WS_matrix):
	newWD_matrix = WD_matrix
	for r in range(0,10):
		for c in range(0,720):
			if math.isnan(WS_matrix[r,c]) and (WD_matrix[r,c] >= 0.0):
				newWD_matrix[r,c] = np.NAN
	return newWD_matrix

##---------------** END **-----------------------------
##-----------------------------------------------------

##-----------------------------------------------------
##              MAIN PROGRAM 
##-----------------------------------------------------


path_in = '/Users/jlundqui/Documents/lidar/ISARRA_2018/'
path_out = path_in

file_count = 2
sorted_files = sorted(glob.iglob(path_in + 'Converted_WLS7-00*_2018_07_14__00_00_00.rtd'), reverse=True) #key=os.path.getctime,  
last_files = [sorted_files[i] for i in np.arange(file_count)]

# read file and retain V_h for one level from each file. Variables to save from each
# file include: lidar, fname, time_array, time_UTC, Azi, V_h

nfile = np.arange(file_count)
big_V_h = []
big_w = []
big_Azi = []
big_fname = []
big_time_str = []
big_time_array = []

for nfile in nfile:
    fname = last_files[nfile].split('/')[-1]

    big_fname.append(fname)
    
    f = open(path_in + fname, encoding='iso-8859-1')  # thanks Leosphere  
    lines=[]
    # Read from File # This line causes problems although can read in data OK otherwise.
    for line in f: 
        lines.append(line.split())
        
        
    lines = lines[57:]
    
    #check which site
    if fname[15:19] == '0068':
        lidar = 'WC68'
        latlon = r"38.09877$^{\circ}$N, -106.17028$^{\circ}$W"
        elev = '2388 m'
        site = 'Saguache'
    elif fname[15:19] == '0049':
        lidar = 'WC49'
        latlon = r"38.09877$^{\circ}$N, -106.17028$^{\circ}$W"
        elev = '2388 m'
        site = 'Saguache'

    if fname[10:14] == 'WLS7':
        print(fname)

        # Convert to numpy format array
        data = np.array(lines)

        if fname[25:27] == '01':
            month = 'Jan'
        elif fname[25:27] == '07':
            month = 'Jul'
        else:
            raise TypeError('That month (' + fname[25:27]  +  ') is not within the calendar year!')

        year = fname[20:24]
        day = fname[28:30]
        mon = fname[25:27]
        hour = fname[32:34]
        min = fname[35:37]

        time_str = data[:,1]
        time_array = np.array([timeStrToFloat(x) for x in time_str.tolist()])

        end_time = 20
        last_time_index = np.min(np.where(time_array > 20)) - 1
        
        data = data[0:last_time_index,:]
        time_array = time_array[0:last_time_index]
        time_str = time_str[0:last_time_index]
        big_time_str.append(time_str)
        big_time_array.append(time_array)
        
        beam_str = data[:,2]
        justdata = data[:,5:]

        n_lines = np.shape(justdata)[0]
        n_heights = np.shape(justdata)[1]/8

        justdata_shaped = np.reshape(justdata,(int(n_lines),int(n_heights),8))
        CNR = justdata_shaped[:,:,0].astype(np.float) #hard to evaluate
        RWS = justdata_shaped[:,:,1].astype(np.float)
        RWSD = justdata_shaped[:,:,2].astype(np.float)
        V_h = justdata_shaped[:,:,3].astype(np.float)
        Azi = justdata_shaped[:,:,4].astype(np.float)
        u = justdata_shaped[:,:,5].astype(np.float)
        v = justdata_shaped[:,:,6].astype(np.float)
        w = justdata_shaped[:,:,7].astype(np.float)
                
        big_V_h.append(V_h)
        big_Azi.append(Azi)
        big_w.append(w)
        
        # PLOTTING
    
        z = np.array([40,60,80,100,120,140,160,180,200,220])
        #timeUTC = np.linspace(0,2401,720)
        timeUTC = np.linspace(0,end_time,n_lines)

        transpose_V_h = np.transpose(V_h)


        fig = plt.figure(figsize=[14,7])
        ax = plt.subplot(111)

        # fontsizes:
        colorbar_fs = 16
        label_fs = 24
        tick_fs = 16
        key_fs = 14

# Now plot a time series at one specific height
        desired_height = 80.
        this_height_index = (np.where(z > desired_height))[0] -1 
        this_height_index = this_height_index[0]
        print(z[this_height_index])
        plt.plot(timeUTC,w[:,this_height_index])
#        plt.plot(timeUTC,V_h[:,this_height_index])
        plt.xlabel('Time (UTC)', fontsize=label_fs)
        plt.ylabel(r'w (m s$^{-1}$)', fontsize=label_fs)
#        plt.ylabel(r'Vhm (m s$^{-1}$)', fontsize=label_fs)
        plt.tick_params(axis='both', which='major', labelsize=tick_fs)
        #ax.xaxis.set_major_formatter(FormatStrFormatter('%02d'))
        plt.suptitle(str(z[this_height_index]) + ' m winds on ' + day + ' '  +  month + ' ' + year + ' '+ site + ' ' + lidar, fontsize=label_fs, x=0.45, y=1)
        plt.title(latlon + ' at ' + elev, fontsize=colorbar_fs, ha='center')
        plt.grid()
#        plt.xlim(8,11)
        plt.xlim(8,11)
#        plt.xlim(10.0425,10.0450) min for WC68
        plt.ylim(-2,2)
#        plt.ylim(0,15)
        plt.show
        plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.WindsTimeSeries' + str(z[this_height_index]) + 'm.png', 
            dpi=300)
#        print(np.where(w[:,this_height_index] eq np.min(w[:,this_height_index])))


# the time series from WC 49 is much noisier than that from WC68

# now need to have both of them on the same axis so that we can calculate an autocorrelation.
print(np.shape(big_V_h))  #now this has two dimensions

#choose one height for cross correlation
desired_height = 80
this_height_index = (np.where(z > desired_height))[0] -1 
this_height_index = this_height_index[0]

# plot a time series of wind speed at desired height vs time for each lidar on the same plot. Different colors.

a = (big_V_h[0])[:,this_height_index]
b = (big_V_h[1])[:,this_height_index]
a = (big_w[0])[:,this_height_index]
b = (big_w[1])[:,this_height_index]
a_x = (big_time_array[0])
b_x = (big_time_array[1])

c = np.correlate(a,b,mode='valid')

#plt.plot(a_x, c)

# By visual inspection have decided at 
offset = -0.339
offset = -0.354  # updated 4 March 2020
#offset = -0.350  # updated 4 March 2020
#offset = -0.346  # updated 4 March 2020
#offset = -0.342  # updated 4 March 2020
offset = -0.338  # updated 4 March 2020
offset = -0.338  # updated 4 March 2020
offset = -0.34  # updated 4 March 2020
#offset = -0.330  # updated 4 March 2020

fig = plt.figure(figsize=[14,7])
ax = plt.subplot(111)

# fontsizes:
colorbar_fs = 16
label_fs = 24
tick_fs = 16
key_fs = 14
        
plt.plot(a_x,a, color='red')
plt.plot(b_x+offset,b, color='blue')
#plt.plot( (big_time_array[0]), (big_V_h[0])[:,this_height_index], color='red')
#plt.plot( (big_time_array[1]), (big_V_h[1])[:,this_height_index]-0.3, color='blue')
plt.ylim(-2,2)
#plt.xlim(8,11)
plt.xlim(10,10.5)
plt.title('Offset of b of '+ str(offset) + ' hr')

a = (big_Azi[0])[:,this_height_index]
b = (big_Azi[1])[:,this_height_index]
a = (big_w[0])[:,this_height_index]
b = (big_w[1])[:,this_height_index]
a_x = (big_time_array[0])
b_x = (big_time_array[1])

#c = np.correlate(a,b,mode='valid')

#plt.plot(a_x, c)

## By visual inspection have decided that offset of -0.338 hours is correct
#offset = -0.339
#offset = -0.354  # updated 4 March 2020
#plt.plot(a_x,a, color='red') #red is 68
#plt.plot(b_x+offset,b, color='blue') # blue is 49
##plt.plot( (big_time_array[0]), (big_V_h[0])[:,this_height_index], color='red')
##plt.plot( (big_time_array[1]), (big_V_h[1])[:,this_height_index]-0.3, color='blue')
#plt.ylim(50,200)
#plt.xlim(8.4,8.6)
#plt.title('Offset of b of '+ str(offset) + ' hr')


# Need to apply an offset of 1220.4 seconds or 20.34 minutes or 0.339 hours. 
# Which system was correct? Rereading of PAtrick's notes at
# https://docs.google.com/document/d/1RAjP7nu-WAbf0bjvjB0V8_0tMQsguLRH84T8hI4Fp2s/edit
# indicate that WC49 is the fast one. This is the second one stored in the array somehow

# Should write out the entire contents of the rtd files just with offset in time. 

#xxx.ppppp.lv.yyyymmdd.hhmmss.cdf
#
#xxx 		- Institute (see appendix 1)
#ppppp		- 5-letter platform identifier (see appendix 2)
#lv		- Data file processing level (see section 4)
#hhmmss	- File start time (UTC) in hours, minutes, seconds
#yyyymmdd	- File date (UTC) in year, month, day, month
#cdf		- NetCDF file extension
#
#As an example, a CU DataHawk NetCDF file collected starting at 11:30:54 UTC on 17 July, 2018 containing non-QC’d physical units would be named: 
#
#UCB.DATHK.a1.20180717.113054.cdf
#UCB:	University of Colorado Boulder
#DPLR1:	CU Doppler Lidar 1
#DPLR2:	CU Doppler Lidar 2
from netCDF4 import Dataset
dataset = Dataset('UCB.DPLR1.a1.20180714.000000.cdf','w',format='NETCDF4_CLASSIC')
#a1: 	Calibration factors applied and converted to geophysical units
#b1: 	QC checks applied to measurements to ensure that they are “in bounds”.  Missing data points or those with bad values should be set to -9999.9

level = dataset.createDimension('level', 10)
#lat = dataset.createDimension('lat', 73)
#lon = dataset.createDimension('lon', 144)
time = dataset.createDimension('time', None)

#All of the Dimension instances are stored in a python
#dictionary. This allows you to access each dimension by
#its name using dictionary key access:
#print 'Lon dimension:'
#, dataset.dimensions['lon']
#for dimname in dataset.dimensions.keys():
# dim = dataset.dimensions[dimname]
# print dimname, len(dim), dim.isunlimited()
#Lon dimension: <type 'netCDF4.Dimension'>: name = 'lon', size = 144
#level 10 False
#time 0 True
#lat 73 False
#lon 144 False
 
## Create coordinate variables for 4-dimensions
times = dataset.createVariable('time', np.float64, ('time',))
levels = dataset.createVariable('level', np.int32, ('level',))
#latitudes = dataset.createVariable('latitude', np.float32,
#('lat',))
#longitudes = dataset.createVariable('longitude', np.float32,
#('lon',))
## Create the actual 4-d variable
#temp = dataset.createVariable('temp', np.float32,
#('time','level','lat','lon'))
wspd = dataset.createVariable('wspd', np.float32,('time','level'))
wdir = dataset.createVariable('wdir', np.float32,('time','level'))

#import time
## Global Attributes
dataset.description = 'bogus example script'
dataset.history = 'Created ' + time.ctime(time.time())
dataset.source = 'netCDF4 python module tutorial'

## Variable Attributes
#latitudes.units = 'degree_north'
#longitudes.units = 'degree_east'
levels.units = 'm'
#temp.units = 'K'
wspd.units = 'm s-1'
wdir.units = 'deg'
times.units = 'I think UTC time but not sure'
#times.calendar = 'gregorian'

#a0: 	Raw data converted to netCDF
#a1: 	Calibration factors applied and converted to geophysical units
#b1: 	QC checks applied to measurements to ensure that they are “in bounds”.  Missing data points or those with bad values should be set to -9999.9
#c1:	Derived or calculated value-added data product (VAP) using one or more measured or modeled data (a0 to c1) as input
#Note: It is NOT required (or expected) to submit all data levels.  Specifically, a0 data may not be useful to many interested users and may not be made available by many groups.  The most useful data levels for most users will likely be a1 and b1, and this is the data level that is most desired from all groups.

#For stationary platforms (e.g. CLAMPS sensors, Doppler Lidars, MURC, stationary towers), these include:
#Index Units:
#UTC Time (Seconds since 00:00:00, 1 January 1970)
UTC_Time = dataset.createDimension('UTC_Time',None)
#Height (m) [for Doppler lidar and possibly AERI retrievals]
Height = dataset.createDimension('Height',10)
MSL = dataset.createDimension('MSL',1)
Lat = dataset.createDimension('Lat',1)
Lon = dataset.createDimension('Lon',1)



data[:] = data_out
# close the file.
ncfile.close()
#print '*** SUCCESS writing example file simple_xy.nc!'

#U = dataset.createDimension('U',)
#Critical (as appropriate):
#MSL Altitude of sensor (m)
#Lat of platform (deg)
#Lon of platform (deg)
#Strongly Desired:
#Temperature (K)
#Pressure (hPa)
#Relative Humidity (%)
#Wind Speed (m/s) [for surface met and radiosonde]
#Wind Direction (deg) [for surface met and radiosonde]
#U wind (m/s) [for Doppler lidar]
#V wind (m/s) [for Doppler lidar]
#W wind (m/s) [for Doppler lidar]
#MWR brightness temperatures (K)
#MWR IR sky temperature (K)
#MWR Precipitable Water (mm)
#MWR Liquid Water Path (mm)
#AERI longwave spectral radiance

#Metadata should provide information that is important in understanding or interpreting the data stream but are not considered significant for naming purposes. Examples of information that could be included in global metadata for a given file includes:
#Location of sensor/platform (if stationary platform)
#QC checks and flags applied
#Calibration procedural information as appropriate
#PI Contact information
#Additionally, for individual variables, information should be included to help the user understand how the measurement was obtained and what it represents.  This could include: 
#Orientation: downwelling, upwelling, or dependent on installation as appropriate.
#Missing data value applied to a given variable (e.g. -9999.9)
#Key information to characterize the measurement
#The instrument/sensor used for the measurement (occasionally important especially if it comes from a data stream containing results from several instruments).
#Time interval information (e.g., averaging time and measurement intervals).
#The units of the measurement
#An indication that the data is a best estimate data or a calculated value data stream. Unless indicated otherwise, it is implicit that the measurement is observed.
