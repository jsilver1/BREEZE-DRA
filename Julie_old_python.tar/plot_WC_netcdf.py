#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 09:01:18 2020

@author: jlundqui
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import math
from matplotlib.ticker import FormatStrFormatter
import glob
import os
import ftplib
import netCDF4
from netCDF4 import Dataset
import pytz, datetime
from datetime import datetime, timezone


# Read in a netcdf file or a few : the 16th at Saguache

path_in = '/Users/jlundqui/Documents/lidar/ISARRA_2018/'
file_to_read = 'UCB.DPLR1.a1.20180716.000000.cdf'
path_out = path_in

fh = Dataset(path_in+file_to_read, mode='r')


#        times[:] = epoch_time
#        heights[:] = z
#        wspd[:] = this_V_h
#        wdir[:] = this_Azi
#        CNR[:] = this_CNR
#        RWS[:] = this_RWS
#        RWSD[:] = this_RWSD
#        u[:] = - this_v # convert from Leosophere convention to meteorological convention
#        v[:] = - this_u # convert from Leosphere convention to meteorological convention
#        w[:] = - this_w # convert from Leosphere convention to meteorological convention


time = fh.variables['time'][:] #epoch seconds
height = fh.variables['height'][:]
wspd = fh.variables['wspd'][:]
wdir = fh.variables['wdir'][:]
u = fh.variables['u'][:]
v = fh.variables['v'][:]
w = fh.variables['w'][:]
#latlon = fh.attributes['latlon'][:]

fh.close()
 
utc_time = [ datetime.fromtimestamp(t, timezone.utc) for t in time ]

wspd[np.where(wspd == -9999.0 )] = np.nan
wdir[np.where(wdir == -9999.0 )] = np.nan


#datetime.fromtimestamp(1423524051, timezone.utc)

#       utc_time = [ datetime.strptime(t, "%Y_%m_%d_%H:%M:%S.%f") for t in complete_str]
#      epoch_time = [ (t - datetime(1970, 1, 1)).total_seconds() for t in utc_time ]


# Make a contour plot of the wind speed and wind direction as in the BAMS paper

fig = plt.figure(figsize=[14,7])
ax = plt.subplot(111)

        # fontsizes:
colorbar_fs = 16
label_fs = 24
tick_fs = 16
key_fs = 14



        #horizontal
contour_levels = np.arange(0, 10, 0.5) #16?
        #contour_levels = np.arange(np.floor(np.nanmin(wm)), np.ceil(np.nanmax(wm)), 0.25)

        #vertical
#        contour_levels = np.arange(-np.ceil(np.nanmax(np.abs(fixed_w))), np.ceil(np.nanmax(np.abs(fixed_w))), 0.25)
#        contour_levels = np.arange(-1.1,1.1,0.2)
        
#barb_stagger = 120 #plot every 20th wind barb


CS = plt.plot(utc_time,wdir[:,1])
CS = plt.plot(utc_time,wdir[:,4])

#CS = plt.contourf(utc_time, height, np.transpose(wspd), contour_levels, extend='max', cmap='viridis')

#B = plt.barbs(timeUTC[::barb_stagger], z, -np.transpose(bigvm)[:,::barb_stagger]*1.94, 
#    -np.transpose(bigum)[:,::barb_stagger]*1.94,
#    barbcolor='black', flagcolor='black', color='black', fill_empty=0, length=5.8, linewidth=1)



#cb_pad = -83#-75
#
#cb = plt.colorbar(format='%.1f', pad=0.05)
#cb.set_label(r'2-min avg horizontal wind speed (filled, m s$^{-1}$)', labelpad=cb_pad, fontsize=colorbar_fs)
ax.set_xlabel('Day of July (UTC)', fontsize=label_fs)
ax.set_ylabel('Wind Direction (deg)', fontsize=label_fs)
#cb.ax.tick_params(labelsize=colorbar_fs)

plt.tick_params(axis='both', which='major', labelsize=tick_fs)

#ax.xaxis.set_major_formatter(FormatStrFormatter('%04d'))
#plt.suptitle(day + ' '  +  month + ' ' + year +' '+ site, fontsize=label_fs, x=0.45, y=1)
#plt.title(latlon + ' at ' + elev, fontsize=colorbar_fs, ha='center')
#plt.grid()
#plt.xlim(14,20)
#plt.ylim(30,160)

savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + '.WindsTimeHeightContour.png', bbox_inches='tight')
        #savedplot = plt.savefig(path_out + 'Lidar.CU_' + site+'.' + year + mon  + day + hour + min  + '.VertWindsTimeHeightContour.png', bbox_inches='tight')

